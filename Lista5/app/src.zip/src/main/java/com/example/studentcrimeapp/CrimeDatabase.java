package com.example.studentcrimeapp;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {Crime.class}, version = 2)
@TypeConverters({Converters.class})
public abstract class CrimeDatabase extends RoomDatabase {
    public abstract CrimeDao crimeDao();
}
